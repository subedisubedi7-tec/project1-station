# 4. Maintenance

## 4.1 Types
| Type | Meaning |
|---|---|
| Breakdown | Fix after failure (avoid for critical items) |
| Preventive (time-based) | Fixed intervals |
| Predictive / CBM | Based on condition: DGA, thermography, PD, SF6 dew point |
| RCM | Reliability-centred; focus on critical failure modes |

## 4.2 Typical schedule (adjust to OEM and utility policy)
| Equipment | Daily / shift | Monthly | Yearly | 3-5 yearly / overhaul |
|---|---|---|---|---|
| Power transformer | Oil level, OTI/WTI, noise, leaks, coolers | Silica gel colour, tank and cable box check | DGA, oil BDV and moisture, IR + PI, thermography, OLTC oil test, protection check | Tan delta / power factor, FRA, winding resistance, turns ratio, OLTC overhaul (by operation count), oil processing |
| SF6 CB | SF6 pressure, spring charged, counters | Heater, pole discrepancy check | Timing, contact resistance, SF6 moisture, mechanism lubrication | Interrupter inspection per OEM (by operations / fault duty) |
| Isolator | Visual | Alignment and contact check | Contact cleaning and greasing, interlock check, motor and limit switch check | Overhaul, replace worn parts |
| CT / CVT | Oil level, leaks | Thermography | IR, tan delta, capacitance | Ratio, magnetisation curve, CVT ratio |
| Surge arrester | Counter, leakage current | Leakage current reading | IR, third-harmonic resistive current, thermography | Replace if leakage trend high |
| Battery / charger | Voltage, earth-fault indication | Cell voltage / specific gravity | Capacity (discharge) test, tighten connections | Replace per life (VRLA about 5-8 y, Ni-Cd about 15 y) |
| Earthing | - | - | Joint check before monsoon | Earth resistance and soil resistivity |
| Relays / panels | Healthy LEDs, time sync | - | Secondary injection, trip test, TCS healthy | Full relay calibration, setting audit |
| Insulators | Visual | - | Cleaning / washing, RTV coating check, thermography | Replace cracked units, check creepage |
| Fire protection | Pressure and valves | Pump run test | Full functional test | System audit |

## 4.3 Thermography (IR scan)
Scan under load (at least 30-50 % load), yearly, twice for critical bays.
Compare with the same part on another phase at the same load: **< 10 C monitor; 10-30 C plan repair; > 30 C urgent.**
Hot spots: clamps, jumpers, isolator blades, CT/CVT top, bushing terminals, LA connection.

## 4.4 Transformer oil care
- Keep oil dry and clean. Change silica gel when the colour changes.
- Sample for DGA, moisture, BDV, acidity, tan delta, interfacial tension, furan (ageing).
- Avoid air ingress during sampling. Do not over-tighten bushings or gaskets.

## 4.5 SF6 gas handling
- SF6 is a strong greenhouse gas (GWP about 23,500). Use a recovery unit, never vent.
- Check by leak detector. Typical leakage < 0.5 % per year per compartment.
- Moisture: new/commissioning typical <= 150 ppmv, in service typical <= 300 ppmv at 20 C. Follow OEM.
- Arc by-products (HF, SOF2) are toxic: use PPE (gloves, respirator) when opening an interrupter.

## 4.6 Shutdown planning steps
Plan with LD -> approve shutdown -> prepare spares and tools -> isolate, earth, PTW -> work + tests -> witness and sign -> restore -> update records.

## 4.7 Spare strategy
Keep strategic spares: spare ICT (or phase spare), bushings, CB poles/interrupters, CT, CVT, LA, relay cards, trip coils, spring-charging motor.
