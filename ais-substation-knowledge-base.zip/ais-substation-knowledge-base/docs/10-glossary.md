# 10. Glossary

| Term | Meaning |
|---|---|
| AIS / GIS | Air / Gas insulated switchgear |
| AR | Auto-reclose |
| CB / ES / ISO | Circuit breaker / earth switch / isolator |
| CT / CVT / VT | Current / capacitor voltage / voltage transformer |
| DGA | Dissolved gas analysis |
| DEF | Directional earth fault |
| DTT | Direct transfer trip |
| ICT | Inter-connecting transformer (400/220 kV autotransformer) |
| LA | Lightning (surge) arrester |
| LBB | Local breaker backup (breaker failure) |
| LD / SLDC / RLDC | Load dispatch centre |
| NGR | Neutral grounding reactor |
| OLTC | On-load tap changer |
| OTI / WTI | Oil / winding temperature indicator |
| PIR | Pre-insertion resistor |
| PLCC | Power line carrier communication |
| PTW | Permit to work |
| PSB / OOST | Power swing block / out-of-step trip |
| REF | Restricted earth fault |
| SOTF | Switch onto fault |
| TCS | Trip circuit supervision |
| TMS / PSM | Time multiplier setting / plug setting multiplier |
| VTFF | VT fuse failure |

## ANSI / IEEE device numbers (common)
| No. | Function | No. | Function |
|---|---|---|---|
| 21 | Distance | 59 | Over-voltage |
| 24 | Over-fluxing (V/Hz) | 63 | Buchholz / pressure |
| 25 | Synchro check | 64R | Restricted earth fault |
| 27 | Under-voltage | 67 / 67N | Directional O/C / E/F |
| 49 | Thermal overload | 68 | Power swing |
| 50 / 51 | Instantaneous / time O/C | 74 | Trip circuit supervision |
| 50N / 51N | Earth fault | 79 | Auto-reclose |
| 50BF | Breaker failure | 85 | Carrier-aided scheme |
| 87T / 87B / 87R / 87L | Differential: transformer / bus / reactor / line | 86 | Lockout relay |
