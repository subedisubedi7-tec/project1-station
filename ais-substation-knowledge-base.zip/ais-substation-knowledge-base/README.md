# 400 / 220 / 132 kV AIS Substation Knowledge Base

Plain-English, exam-friendly notes on **Air Insulated Switchgear (AIS) substations**:
operation, maintenance, testing, relay settings and coordination.

> **Disclaimer:** Educational material. Values marked *typical* vary by utility, OEM and standard
> (IEC, IEEE, IS, CEA, NEA, POWERGRID practice). Always follow your utility's rules, the OEM manual
> and the approved relay setting sheet. Never use these notes in place of safety rules or a Permit to Work.

## Contents

| File | Topic |
|---|---|
| [docs/01-fundamentals.md](docs/01-fundamentals.md) | Voltage classes, bus schemes, clearances, bay layout |
| [docs/02-equipment.md](docs/02-equipment.md) | Transformer, CB, isolator, CT, CVT, LA, reactor, battery, earthing |
| [docs/03-operation.md](docs/03-operation.md) | Switching rules, sequences, interlocks, PTW, emergencies |
| [docs/04-maintenance.md](docs/04-maintenance.md) | Maintenance types, schedules, thermography, oil and SF6 care |
| [docs/05-testing.md](docs/05-testing.md) | Commissioning and routine tests with typical acceptance values |
| [docs/06-protection-schemes.md](docs/06-protection-schemes.md) | Protection for line, transformer, bus, reactor, LBB, AR |
| [docs/07-relay-settings-coordination.md](docs/07-relay-settings-coordination.md) | Setting methods + worked examples |
| [docs/08-checklists.md](docs/08-checklists.md) | Daily log, PTW, shutdown, test report, relay data sheet |
| [docs/09-exam-qa.md](docs/09-exam-qa.md) | Short exam-style questions and answers |
| [docs/10-glossary.md](docs/10-glossary.md) | Abbreviations and ANSI device numbers |
| [tools/relay_calc.py](tools/relay_calc.py) | Python helpers: fault level, IDMT, distance zones, CT knee point |

## Quick start

```bash
python3 tools/relay_calc.py            # prints worked examples
python3 -m pytest tools -q             # optional: run tests (needs pytest)
```

## Upload to GitHub

```bash
unzip ais-substation-knowledge-base.zip && cd ais-substation-knowledge-base
git init && git add . && git commit -m "Initial commit: AIS substation knowledge base"
git branch -M main
git remote add origin https://github.com/<your-username>/<repo-name>.git
git push -u origin main
```
(Create the empty repository on github.com first, without a README.)

## License
MIT - see [LICENSE](LICENSE).
