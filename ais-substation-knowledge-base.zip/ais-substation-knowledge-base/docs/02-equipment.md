# 2. Major Equipment

## 2.1 Power transformer / ICT (autotransformer 400/220 kV, 315 or 500 MVA)
| Part | Job |
|---|---|
| Core and winding | Magnetic circuit and electric circuit |
| Tertiary (33 kV, delta) | Stabilises zero-sequence, supplies station auxiliary / reactors |
| OLTC (on-load tap changer) | Voltage control, about +/-10 %, 16-33 steps |
| Buchholz relay | Gas (alarm) and oil surge (trip). Main tank only |
| PRV / PRD | Pressure relief on severe internal fault |
| OTI / WTI | Oil and winding temperature. Typical: oil alarm 85 C / trip 95 C; winding alarm 95-100 C / trip 105-110 C |
| MOG | Magnetic oil gauge, low oil alarm |
| Breather (silica gel) | Dries air. Blue/orange = good, pink/white = change |
| Bushings (OIP / RIP) | Bring winding out. Check tan delta and oil level |
| Cooling | ONAN -> ONAF -> OFAF/ODAF; fans/pumps by WTI stages |
| Fire protection | Nitrogen injection (NIFPS) or high-velocity water spray |
| Marshalling box | Control, alarms, trip contacts |

## 2.2 Circuit breaker (CB)
- Type: SF6 puffer / self-blast. Mechanism: spring (common) or hydraulic.
- 400 kV: 2 breaks per pole typical, **pre-insertion resistor (PIR)** or controlled switching to limit switching surge.
- Two trip coils (TC1, TC2) on separate DC supplies. One close coil.
- SF6 density monitor stages: alarm (refill) -> lock-out (no operation allowed).
- Duties: make/break short circuit, auto-reclose (O - 0.3 s - CO - 3 min - CO), line charging, capacitive switching.

## 2.3 Isolator / disconnector
- No arc quenching. **Never operate on load.** Gives a visible isolation gap.
- Types: horizontal centre-break, double-break, pantograph, vertical break.
- Earth switch (ES) with mechanical + electrical interlock to the isolator.
- Motor operated, local/remote selector. Manual handle for emergency.

## 2.4 Current transformer (CT)
- Oil-filled inverted type (400/220 kV). Secondary 1 A (long cable runs) or 5 A.
- Cores per bay (typical): metering (0.2S), protection (5P20 / PS class for bus and distance relays), bus protection cores.
- **Never open-circuit a live CT secondary** (dangerous high voltage). Short it first.
- PS class is defined by knee-point voltage Vk and RCT.

## 2.5 Capacitor voltage transformer (CVT)
- Capacitor divider + electromagnetic unit (EMU). Secondary 110/sqrt3 V (63.5 V).
- Also couples PLCC carrier. Has ferro-resonance suppression circuit.
- **Never short-circuit a VT secondary** (fuse/MCB protects it).

## 2.6 Surge arrester (LA)
- Metal oxide (ZnO) gapless. Place close to transformer and at line entry.
- Typical rated voltage (effectively earthed): 400 kV -> 336 kV; 220 kV -> 198 kV; 132 kV -> 120 kV.
- Discharge current typical: 400 kV 20 kA; 220/132 kV 10 kA.
- Surge counter + leakage current meter on each LA. Record every month.

## 2.7 Wave trap and PLCC
Wave trap blocks carrier (40-500 kHz) from entering the station bus. Used for carrier-aided protection, speech and data.

## 2.8 Shunt reactor
400 kV line reactors (50/63/80 MVAr) control line-charging voltage rise (Ferranti effect). Neutral grounding reactor (NGR) helps single-phase auto-reclose by reducing secondary arc current.

## 2.9 Busbar and conductors
ACSR Moose / Twin Moose / Quad Moose (400 kV), tubular aluminium alloy bus. Clamps and joints are the main hot-spot sources.

## 2.10 Earthing
Grid of MS flat/rod buried about 0.5-0.6 m. Target grid resistance: **<= 1 ohm** (large substations often <= 0.5 ohm). Design for step and touch voltage as per IEEE 80. Every structure, tank, LA and fence is bonded to the grid.

## 2.11 DC system and auxiliaries
- 220 V / 110 V DC and 48 V DC batteries with float + boost chargers (2 x 100 %).
- Lead-acid: float about 2.25 V/cell, boost about 2.7 V/cell. Ni-Cd: float about 1.40-1.42 V/cell.
- LT AC: two incoming sources + DG set with auto changeover.
- Fire fighting: hydrant, HVWS, portable extinguishers, fire alarm.
