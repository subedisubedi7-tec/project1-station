# 5. Testing (Commissioning and Routine)

> Acceptance values below are *typical*. Final limits come from the OEM test certificate, IEC/IEEE/IS standard, and utility policy.

## 5.1 Test instruments
Insulation tester (5 / 10 kV), micro-ohm meter (100 A DC), tan delta / capacitance kit, CT/PT analyser, CB analyser (timing + travel), relay test set (secondary injection), primary injection set, DGA kit, SF6 dew-point meter and purity analyser, thermal imager, earth tester, FRA analyser, partial discharge (PD / UHF) kit, battery discharge tester.

## 5.2 Power transformer / ICT
| Test | Typical acceptance | Note |
|---|---|---|
| IR (HV-E, LV-E, HV-LV) at 5 / 10 kV | >= 1000 MOhm at 20 C (compare with factory and previous) | IR roughly halves for every 10 C rise. Correct to 20 C |
| Polarisation index (10 min / 1 min) | >= 1.5 (above 2.0 is good) | DAR (60 s / 30 s) >= 1.25 |
| Winding resistance (all taps) | Phase-to-phase difference <= 1-2 %; within +/-5 % of factory after temperature correction | Do not measure right after IR test; discharge first |
| Voltage ratio, all taps | +/-0.5 % of nameplate | Also vector group and polarity |
| Magnetising current | Two outer phases similar, centre phase lower | Compare with factory |
| Short-circuit impedance | within about +/-2 % of factory/nameplate | Pre/post transport and after faults |
| Tan delta (winding) at 10 kV | <= 0.5 % new, <= 0.7 % service (at 20 C) | Also capacitance change <= 5 % |
| Bushing tan delta + capacitance | <= 0.5 % (OIP new), <= 0.7 % (service); capacitance change <= 5 % | Use test tap |
| FRA | Phases overlap; no big shifts | Baseline needed |
| Oil BDV | > 60 kV (Um > 170 kV), > 50 kV (72.5-170 kV) in service; new oil >= 70 kV | IEC 60422 |
| Oil moisture | <= 10 ppm new; <= 15 ppm service (400/220 kV) | Temperature dependent |
| Oil tan delta at 90 C | <= 0.01 new, <= 0.1 limit in service | |
| Core earth IR | >= 100 MOhm, single earth only | Two core earths make circulating current |
| Protection and cooling | All alarms/trips operate, fans/pumps auto | Check Buchholz, PRV, OTI/WTI, OLTC |

### DGA (dissolved gas analysis) - quick guide
| Gas | Fault indicated |
|---|---|
| H2 | Partial discharge (corona) |
| CH4 and C2H6 | Low-temperature overheating |
| C2H4 | High-temperature overheating (> 300-700 C) |
| C2H2 | **Arcing** (any rising value is serious) |
| CO, CO2 | Paper (cellulose) overheating. CO2/CO < 3 = severe paper fault, > 10 = normal ageing |

Methods: IEC 60599 ratios, Duval triangle 1, IEEE C57.104 limits. Look at the **rate of rise**, not only the value. Typical routine: yearly for ICT, every 2-3 years for 132 kV, more often if gas is rising.

## 5.3 Circuit breaker (SF6)
| Test | Typical acceptance |
|---|---|
| IR (pole-to-earth, across open contacts) at 5 kV | >= 1000 MOhm |
| Contact resistance (100 A DC) | <= OEM limit (typical tens to about 150 micro-ohm per pole) |
| Timing: closing, opening, close-open | Within OEM values (typical close 80-120 ms, open 20-40 ms) |
| Pole discrepancy | Typical <= 3.33 ms (open), <= 5 ms (close), or as OEM |
| PIR resistance (400 kV) and insertion time | Within +/-5 % of nameplate / OEM time |
| Minimum operating voltage | Close at 85 % DC, trip at 70 % DC (IEC 62271-100: 85-110 % close, 70-110 % trip) |
| SF6 gas: moisture, purity, leakage | Moisture and leakage as 4.5; purity >= 97 % |
| Density monitor | Alarm and lock-out contacts at nameplate pressure |
| Dynamic contact resistance (DCRM) | Smooth curve, no spikes (shows arcing contact wear) |
| Coil current signature | Compare with baseline |

## 5.4 Isolator and earth switch
IR, contact resistance (follow OEM; typical a few hundred micro-ohm at most), manual and motor operation, travel limits, alignment of blades, interlock functional test, auxiliary contact status.

## 5.5 Current transformer
| Test | Typical acceptance |
|---|---|
| Polarity | P1 towards bus (or as per SLD) |
| Ratio (each tap, each core) | Within class (0.2S, 5P) |
| Magnetising curve / knee point | Vk >= specified; Im at Vk within spec; compare with nameplate |
| Winding resistance RCT | Within +/-10 % of factory |
| IR primary-earth / secondary-earth | >= 1000 MOhm / >= 100 MOhm (500 V) |
| Tan delta and capacitance | <= 0.5 % (new), <= 0.7 % (service); capacitance change <= 5 % |
| Burden | Total burden <= rated burden |
| Oil CT: DGA | C2H2 nil, low H2 |

## 5.6 CVT
Capacitance C1, C2 and tan delta (<= 0.5 % typical; capacitance deviation within about +/-5 % of nameplate), ratio and phase error, EMU secondary voltage, ferro-resonance damping check, drain coil and carrier coupling check.

## 5.7 Surge arrester
IR (>= 1000 MOhm at 5 kV), leakage current (total and resistive third-harmonic) by arrester monitor, thermography, counter and ground lead check. **Trend is key:** a clear rise (for example 2-3 times earlier value, or rising resistive part) means suspect - plan replacement. Alarm limits per OEM.

## 5.8 Earthing
- Fall-of-potential (62 % rule) for resistance, target <= 1 ohm (<= 0.5 ohm for large 400 kV).
- Wenner 4-pin soil resistivity.
- Joint resistance of risers and equipment bonds (micro-ohm level), continuity to grid.
- Step and touch voltage checks after design changes.

## 5.9 Protection relay and secondary
- Settings verification vs approved sheet (print and sign).
- Secondary injection: pickup, drop-off ratio, operating time at 2 points, directional boundary, zone reach (Z1, Z2, Z3).
- Stability test (differential / bus bar) by primary injection or load check.
- CT/VT circuit: polarity, loop resistance, insulation (500 V DC >= 1 MOhm), single earthing point.
- Trip circuit supervision healthy for both TC1 and TC2.
- Carrier: send/receive test, guard level, signal margin (daily carrier check where used).
- GPS time sync, disturbance recorder triggers, IEC 61850 GOOSE tests.
- End-to-end test with remote end for line protection.

## 5.10 Battery bank
Cell voltage, specific gravity, capacity discharge test (pass at >= 80 % rated capacity), internal resistance (VRLA), charger float/boost voltage setting, ripple, earth-fault relay.

## 5.11 Temperature correction of IR
Approximate: IR at 20 C = IR measured x 2^((T - 20) / 10), where T is the winding/oil temperature in C. (Measured at 40 C, IR is about 4x lower than at 20 C.)
