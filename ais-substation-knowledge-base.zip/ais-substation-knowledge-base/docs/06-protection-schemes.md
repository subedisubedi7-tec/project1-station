# 6. Protection Schemes

## 6.1 Philosophy
Dependable (trip when it must), secure (not when it must not), fast, selective, sensitive. **Main-1 and Main-2** (different make/principle) plus backup. Two DC sources, two trip coils, breaker failure protection.

## 6.2 Scheme by element
| Element | Main protection | Backup / extra |
|---|---|---|
| **400 kV line** | Main-1 and Main-2 numerical distance (21) with carrier aided scheme (85) | DEF (67N), over-voltage (59) stage 1 and 2, stub (50STUB), SOTF, power swing (68), auto-reclose (79), LBB (50BF), direct transfer trip (DTT) on reactor/LBB trip |
| **220 kV line** | Distance (21) main + backup distance or O/C-E/F | DEF, AR, LBB, VTFF |
| **132 kV line** | Distance (21) + back-up IDMT O/C and E/F (51, 51N) | AR, LBB (if applicable) |
| **ICT / transformer** | Differential (87T) with 2nd and 5th harmonic restraint | REF (64R / 87N), HV and LV O/C-E/F (51/51N), over-fluxing (24), OLTC, Buchholz (63), PRD, OTI/WTI, overload alarm, LBB |
| **Bus bar** | Bus bar differential (87B), low-impedance or high-impedance, with check zone | LBB tripping logic, CT supervision |
| **Bus reactor / shunt reactor** | Reactor differential (87R), REF | Buchholz, WTI, O/C-E/F backup |
| **Bus coupler / tie** | O/C and E/F (51 / 51N) | LBB |
| **Capacitor bank (132/33)** | Unbalance (51NC), O/C, over-voltage | Discharge reactor, NCT |
| **Station** | DC supervision, trip circuit supervision (74), lockout (86) | AC supply failure alarm |

## 6.3 Distance protection (21) - essentials
- Measures impedance Z = V / I and compares it with a reach set on the R-X plane (mho or quadrilateral shape).
- Zones: Z1 instantaneous (under-reach), Z2 time-delayed, Z3 backup, Z4 reverse.
- Earth-fault elements need the residual compensation factor kN.
- **Carrier-aided schemes:**
  - **PUTT** (permissive under-reach): Z1 sends permissive; Z2 + receive = fast trip.
  - **POTT** (permissive over-reach): Z2 sends permissive; Z2 + receive = fast trip. Needs weak-end infeed/echo and current reversal logic.
  - **Blocking scheme:** Z3-reverse sends block. Fast trip if no block is received.
- Additional logics: SOTF (switch onto fault), VTFF (VT fuse failure) blocks distance, PSB / OOST (power swing), load encroachment, stub protection (1.5 CB).

## 6.4 Transformer differential (87T)
- Compare currents after correcting for **ratio** and **phase shift** (numerical relays do both; for electromechanical use CT connection opposite to winding).
- Percentage bias characteristic: pickup (Id>) + slope 1 + slope 2 + high-set unrestrained (Id>>).
- Inrush restraint by 2nd harmonic (typical 15-20 %). Over-excitation restraint by 5th harmonic (typical 25-35 %).
- Does not cover external faults. REF improves earth-fault sensitivity close to the neutral.

## 6.5 Bus bar protection
- **High impedance:** simple and stable, needs equal ratio CTs and a CT knee-point voltage >= 2 x setting voltage.
- **Low impedance (numerical, biased):** more flexible, CT ratio mismatch accepted, dynamic zone selection by isolator status.
- Check zone: trips only if both discriminating zone and check zone operate.

## 6.6 Breaker failure protection (LBB / 50BF)
- Starts when a protection trips and current still flows after the CB trip time.
- Stage 1: retrip same breaker (optional). Stage 2: trip all breakers connected to that bus section (and send DTT to remote end).
- Timer = CB opening time + relay reset time + margin. Typical total 150-200 ms. Current detector typically 0.2 x In.

## 6.7 Auto-reclose (79)
- 400 / 220 kV: single-phase AR (dead time about 1 s; typical, depends on secondary arc extinction) for single-phase faults, three-phase trip for multi-phase faults.
- 132 kV: three-phase AR for radial or lightly loaded lines (dead time 0.3-1 s).
- Reclaim time typical 10-25 s. Needs synchro check for three-phase reclose.
- Block AR on: LBB trip, bus bar trip, transformer trip, cable fault, SOTF trip, repeated faults.

## 6.8 Overvoltage protection (59), typical
Stage 1 about 1.10 pu with a delay of about 5 s (alarm / trip); Stage 2 about 1.40 pu with about 100 ms. Used on long 400 kV lines. Follow grid code.

## 6.9 CT and VT requirements
- Distance relay CT: PS class, Vk >= K x If x (RCT + RL + Rrelay) where K from relay maker (typically 1-2 depending on X/R). Use 1 A secondary on long cables.
- Bus bar CT: PS class with equal ratio and Vk >= 2 x Vs for high impedance.
- Metering class 0.2S, burden within limit. Check **saturation** for worst-case fault + DC offset.
- VT: 0.2/3P class, 110/sqrt3 V. Single earth point, MCB protection for each secondary circuit.

## 6.10 Time synchronisation and communication
GPS/IRIG-B or SNTP, IEC 61850 station bus (GOOSE for interlock/trip), process bus where used, SCADA IEC 60870-5-104.
