"""relay_calc.py - small helpers for substation relay setting studies.

Plain Python 3, no extra packages.  Run:  python3 tools/relay_calc.py
All results are for study/exam use. Check with the utility's approved method.
"""
import math

# IEC 60255-151 inverse curves:  t = TMS * k / ((I/Is)**a - 1)
CURVES = {
    "NI": (0.14, 0.02),    # normal inverse
    "VI": (13.5, 1.0),     # very inverse
    "EI": (80.0, 2.0),     # extremely inverse
    "LTI": (120.0, 1.0),   # long-time inverse
}


# ---------- Fault level and load current ----------
def mva_to_ka(mva, kv):
    """Short-circuit MVA -> kA at line voltage kv."""
    return mva / (math.sqrt(3) * kv)


def ka_to_mva(ka, kv):
    return math.sqrt(3) * kv * ka


def series_mva(*mvas):
    """Combine fault MVAs in series (source + transformer)."""
    return 1.0 / sum(1.0 / m for m in mvas)


def xfmr_fault_mva(rated_mva, z_pct, source_mva=None):
    """Fault MVA on the secondary side. source_mva=None means infinite bus."""
    t = rated_mva / (z_pct / 100.0)
    return t if source_mva is None else series_mva(t, source_mva)


def full_load_current(mva, kv):
    """Rated current in amperes."""
    return mva * 1000.0 / (math.sqrt(3) * kv)


# ---------- IDMT over-current ----------
def idmt_time(i_fault, i_pickup, tms, curve="NI"):
    k, a = CURVES[curve]
    psm = i_fault / i_pickup
    if psm <= 1.0:
        return math.inf
    return tms * k / (psm ** a - 1.0)


def tms_for_time(t, i_fault, i_pickup, curve="NI"):
    k, a = CURVES[curve]
    psm = i_fault / i_pickup
    return t * (psm ** a - 1.0) / k


# ---------- Distance relay ----------
def distance_zones(line_ohm, shortest_adj_ohm, longest_adj_ohm, ctr, vtr):
    """Primary and secondary ohm reach for Z1, Z2, Z3 (common Indian practice)."""
    z1 = 0.8 * line_ohm
    z2 = max(line_ohm + 0.5 * shortest_adj_ohm, 1.2 * line_ohm)
    z3 = 1.2 * (line_ohm + longest_adj_ohm)
    factor = ctr / vtr                      # primary ohm -> secondary ohm
    return {n: (z, z * factor) for n, z in (("Z1", z1), ("Z2", z2), ("Z3", z3))}


def residual_comp(z0, z1):
    """kN = (Z0 - Z1) / (3 Z1); z0, z1 may be complex."""
    return (z0 - z1) / (3 * z1)


# ---------- CT and bus bar ----------
def hz_bus_setting(if_pri_ka, ctr, rct, rl_oneway):
    """High-impedance bus bar: stabilising voltage Vs and min CT knee point."""
    i_sec = if_pri_ka * 1000.0 / ctr
    vs = i_sec * (rct + 2.0 * rl_oneway)
    return vs, 2.0 * vs


def tr_ct_current(mva, kv, ctr):
    """Secondary current of a transformer winding CT at full load."""
    return full_load_current(mva, kv) / ctr


def _demo():
    print("1) Fault level")
    src = ka_to_mva(40, 400)
    print(f"   400 kV, 40 kA = {src:,.0f} MVA")
    f = xfmr_fault_mva(315, 12.5, src)
    print(f"   315 MVA ICT 12.5 % infeed at 220 kV = {f:,.0f} MVA = {mva_to_ka(f, 220):.2f} kA")

    print("2) IDMT grading (NI curve, 4000 A fault)")
    t_b = idmt_time(4000, 400, 0.1)
    tms_a = tms_for_time(t_b + 0.4, 4000, 800)
    print(f"   Downstream relay B: {t_b:.3f} s")
    print(f"   Upstream relay A needs TMS {tms_a:.3f} -> set 0.175, "
          f"t = {idmt_time(4000, 800, 0.175):.3f} s")

    print("3) Distance zones (220 kV, 40 km line, CT 800/1, CVT 220kV/110V)")
    z = distance_zones(16, 8, 24, 800, 2000)
    for name, (p, s) in z.items():
        print(f"   {name}: {p:.1f} ohm primary = {s:.2f} ohm secondary")
    print(f"   kN (Z0/Z1 = 3, same angle) = {abs(residual_comp(3 + 0j, 1 + 0j)):.3f}")

    print("4) High-impedance bus bar")
    vs, vk = hz_bus_setting(40, 2000, 5, 2)
    print(f"   Vs = {vs:.0f} V, CT knee point >= {vk:.0f} V")

    print("5) Transformer 100 MVA 220/132 kV differential matching")
    ih = tr_ct_current(100, 220, 400)
    il = tr_ct_current(100, 132, 600)
    print(f"   HV CT 400/1: {ih:.3f} A, LV CT 600/1: {il:.3f} A, ratio {il / ih:.3f}")


if __name__ == "__main__":
    _demo()
