import math
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
import relay_calc as rc


def test_fault_level():
    assert abs(rc.ka_to_mva(40, 400) - 27712.8) < 1
    assert abs(rc.mva_to_ka(27712.8, 400) - 40) < 1e-3


def test_xfmr():
    f = rc.xfmr_fault_mva(315, 12.5, rc.ka_to_mva(40, 400))
    assert 2300 < f < 2320


def test_idmt():
    assert abs(rc.idmt_time(4000, 400, 0.1) - 0.297) < 0.001
    assert math.isinf(rc.idmt_time(300, 400, 0.1))
    assert abs(rc.tms_for_time(0.697, 4000, 800) - 0.1629) < 0.001


def test_distance():
    z = rc.distance_zones(16, 8, 24, 800, 2000)
    assert abs(z["Z1"][0] - 12.8) < 1e-9 and abs(z["Z1"][1] - 5.12) < 1e-9
    assert abs(z["Z2"][0] - 20.0) < 1e-9 and abs(z["Z2"][1] - 8.0) < 1e-9
    assert abs(z["Z3"][0] - 48.0) < 1e-9 and abs(z["Z3"][1] - 19.2) < 1e-9


def test_kn_and_bus():
    assert abs(abs(rc.residual_comp(3, 1)) - 2 / 3) < 1e-9
    vs, vk = rc.hz_bus_setting(40, 2000, 5, 2)
    assert abs(vs - 180) < 1e-9 and abs(vk - 360) < 1e-9


def test_transformer_ct():
    assert abs(rc.tr_ct_current(100, 220, 400) - 0.656) < 0.001
    assert abs(rc.tr_ct_current(100, 132, 600) - 0.729) < 0.001
