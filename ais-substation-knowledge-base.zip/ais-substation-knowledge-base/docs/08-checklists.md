# 8. Checklists and Templates

## 8.1 Shift / daily inspection
- [ ] Annunciation clear (or known alarms logged)
- [ ] Bus voltages and frequency within limits
- [ ] Transformer: oil level, OTI/WTI readings, cooler status, tap position, noise, leaks
- [ ] CB: SF6 pressure (all poles), spring charged, operation counter
- [ ] LA: leakage current and counter reading recorded
- [ ] DC: battery voltage, charger status, earth-fault indicator
- [ ] AC auxiliary: both sources, DG ready
- [ ] Carrier / PLCC check done and logged
- [ ] Fire system: pump auto, tank level, nitrogen cylinder pressure
- [ ] Switchyard walk: sparks, hot joints, broken insulators, bird nests, oil leaks, fence and gates
- [ ] Log book updated and signed

## 8.2 Shutdown / PTW checklist
- [ ] Shutdown approved by LD (reference no. and time)
- [ ] Switching programme written and checked by a second person
- [ ] CB open, isolators open, locked and tagged
- [ ] Voltage absent proven with a tester
- [ ] Earth switches closed / portable earths applied (both sides)
- [ ] Danger boards and barriers placed
- [ ] PTW issued, work area marked
- [ ] Work completed, tools/materials removed, PTW returned
- [ ] Earths removed, tags removed, tests recorded
- [ ] LD informed and restoration order received

## 8.3 Pre-charging checklist (new/after maintenance)
- [ ] All PTWs cancelled
- [ ] Earth switches/portable earths removed
- [ ] Protection relays in service, correct setting group
- [ ] CT secondaries not open, VT MCBs on
- [ ] Tripping and alarm circuits tested, TCS healthy
- [ ] SF6 pressure, oil level, tap position, cooler auto
- [ ] Buchholz air released, valves open
- [ ] IR and oil test records OK
- [ ] Fire system ready, personnel clear
- [ ] Charge and watch currents, voltage, temperatures, noise for 30 min

## 8.4 Transformer test report (template)
| Item | Value |
|---|---|
| Station / Bay / Serial no. | |
| Date / Ambient / Oil temp | |
| IR 15 s / 60 s / 600 s (HV-E, LV-E, HV-LV) | |
| PI / DAR | |
| Winding resistance (each tap, each phase) | |
| Ratio (each tap) | |
| Magnetising current | |
| Tan delta / capacitance (winding, bushings) | |
| FRA reference | |
| Oil: BDV / moisture / tan delta / DGA | |
| Remarks / Test engineer / Witness | |

## 8.5 Relay setting data sheet (template)
| Item | Value |
|---|---|
| Station / Bay / Relay make, model, firmware | |
| CT ratio / class, VT ratio | |
| Setting group, date, approved by | |
| Z1 / Z2 / Z3 / Z4 reach (ohm), timer (ms) | |
| kN / kM, load blinder | |
| Carrier scheme, AR mode, dead time | |
| Over-current / E/F: pickup, curve, TMS | |
| Differential: Id>, slope 1/2, Id>>, harmonic blocks | |
| LBB timer / current | |
| Test report no. / Date tested / Engineer | |

## 8.6 Trip report format
Date and time - Station and bay - Relay flags and event numbers - Fault location and current/voltage values from the disturbance record - AR operation - Weather - Action taken - Root cause - Time of restoration.
