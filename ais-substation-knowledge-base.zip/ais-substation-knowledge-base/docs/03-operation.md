# 3. Substation Operation

## 3.1 Golden rules
1. **Isolator never opens or closes on load.** CB first, isolator second.
2. Operate only with a valid order from the control centre (LD) and make a log book entry.
3. Check **earth switches, PTW and interlocks** before charging anything.
4. Safety first: Permit to Work (PTW), Lock Out Tag Out (LOTO), test before touch, earth on both sides.
5. If an interlock blocks you, **do not bypass it** without written authority and a risk check.

## 3.2 Switching sequences
**Taking a feeder out (line bay, double bus):**
1. Open CB (remote). 2. Open line isolator. 3. Open bus isolator. 4. Close line earth switch. 5. Close other earth switches as the PTW requires.

**Putting it back:**
1. Remove earths, check PTW cancelled. 2. Close bus isolator. 3. Close line isolator. 4. Close CB (synchro-check ON).

Memory aid: **"CB first to open, last to close."**

**Transformer / ICT charging:** Charge from the **higher voltage side** (better protection sensitivity), then load by closing the LV breaker. De-energise in reverse. Check tap position, OLTC mode, cooling on auto.

**Line charging:** Charge from the end with the strong source and lower voltage rise. Watch the Ferranti effect (receiving-end voltage rises). Keep the line reactor in service.

**Bus transfer (no outage, double bus):** Close bus coupler and block its trip -> close the feeder's isolator on the second bus -> open its isolator on the first bus -> restore the coupler trip. Isolators here only carry out make-before-break between equal-potential buses.

## 3.3 Interlocks
| Interlock | Purpose |
|---|---|
| ES vs isolator | Earth switch cannot close if isolator closed (and the reverse) |
| Isolator vs CB | Isolator operates only when CB is open |
| Bus transfer | Two bus isolators of one feeder only if bus coupler closed |
| Line ES | Closes only after line is dead (voltage check) |
| Key interlock | Last defence when electrical logic is faulty |

## 3.4 Permit to Work (PTW) in brief
1. Request -> 2. Isolate and earth -> 3. Danger boards and fence the zone -> 4. Issue PTW to person in charge -> 5. Work -> 6. Return PTW -> 7. Remove earths -> 8. Restore.
One PTW per isolated section. Keep the key and tag log.

## 3.5 Voltage and reactive power control
- Voltage band (typical): 400 kV 380-420 kV; 220 kV 198-245 kV; 132 kV 119-145 kV (follow the grid code).
- Tools: ICT OLTC, shunt reactors, capacitor banks, SVC/STATCOM, generator AVR.
- High voltage at light load -> reactor in / capacitor out. Low voltage at peak -> capacitor in / tap raise.

## 3.6 Operator rounds
Shift take-over, annunciation, SF6 pressure, oil levels, temperatures, DC voltage and earth-fault indication, battery charger, fans, noise/smell, LA leakage current, sparking, bird nests, fire system ready.

## 3.7 Emergency actions
| Event | First actions |
|---|---|
| Transformer trip on Buchholz / PRV / differential | Do not recharge. Inform LD, record relay flags, take oil/gas sample, test before re-energising |
| Line trip | Note relay flags and fault location, report to LD. Charge only on LD instruction |
| Bus bar protection operated | Isolate bus, inspect (flash marks, broken insulators), restore healthy bus first |
| SF6 low (lock-out) | Do not operate that CB. Open adjacent CBs to isolate the bay, call maintenance |
| DC earth fault | Locate by feeder selection. A second earth can cause false trips |
| Fire | Trip and isolate, start fire system, call fire brigade, keep clear of oil spill |
| Total blackout | Start DG for auxiliaries, check which lines are live, follow restoration plan |

## 3.8 Records
Log book, trip report with relay flags and fault records (disturbance record / event log), shutdown register, PTW register, defect register, battery record, transformer loading and temperature log.
