# 9. Exam-style Questions and Answers (short)

**Q1. Why is the 1.5 CB scheme used at 400 kV?**
High reliability: any CB or bus can be maintained with no outage. Each circuit has two paths. Cost is 1.5 CB per circuit.

**Q2. Write the order to isolate a feeder.**
Open CB -> open line isolator -> open bus isolator -> close earth switch. (Reverse to restore, CB last.)

**Q3. Why must an isolator not be operated on load?**
It has no arc-quenching ability. It would draw a long arc and may cause a fault and injury.

**Q4. Why not open a CT secondary?**
Flux rises, causing very high voltage on the secondary. It can damage insulation and kill. Short the secondary first.

**Q5. Why is a VT secondary never shorted?**
Very large current would flow and burn the VT. Fuses or MCB protect it.

**Q6. Name three transformer protections.**
Differential (87T), Buchholz (63), REF (64R). Also over-flux, OTI/WTI, PRD, back-up O/C-E/F.

**Q7. What causes magnetising inrush and how does the relay avoid mis-trip?**
Core saturation on energisation (peaks up to 8-12 x rated, rich in 2nd harmonic). 2nd harmonic restraint blocks 87T.

**Q8. What is over-fluxing and its protection?**
Flux is proportional to V/f. High V or low f saturates the core, heats it. Protect with V/Hz relay (24): alarm about 1.1 pu, trip about 1.25 pu with time delay.

**Q9. Distance relay zone settings?**
Z1 = 80 % of line, instantaneous. Z2 = 100 % line + 50 % of shortest adjacent line (at least 120 % of line), about 350 ms. Z3 = about 120 % of (line + longest adjacent line), about 800-1000 ms.

**Q10. Why is Z1 only 80 %?**
Errors in CT/VT, line data and arc resistance. 100 % could over-reach into the next line and trip wrongly.

**Q11. What is the residual compensation factor kN?**
kN = (Z0 - Z1) / (3 x Z1). Corrects reach for earth faults in the ground element.

**Q12. PUTT vs POTT?**
PUTT: sender is under-reaching Z1. POTT: sender is over-reaching Z2. POTT is faster for end-zone faults, needs weak infeed and current-reversal logic.

**Q13. What is breaker failure protection?**
If a CB fails to open, LBB trips all adjacent CBs of the bus after a timer (about 150-200 ms).

**Q14. Why is single-phase auto-reclose used on 400 kV?**
Most faults are single-phase and transient. Tripping only that phase keeps the other two carrying power, so stability is better.

**Q15. What is the Ferranti effect?**
Voltage rise at the open/lightly loaded receiving end of a long line due to charging current. Reduce with shunt reactors.

**Q16. IDMT formula (IEC normal inverse)?**
t = TMS x 0.14 / ((I / Is)^0.02 - 1).

**Q17. Time grading margin for O/C relays?**
0.3-0.4 s for numerical relays (0.4-0.5 s for older types). It covers CB opening time, relay overshoot and error.

**Q18. How do you size CT knee-point for high-impedance bus protection?**
Vs = If_sec x (RCT + 2RL). Choose Vk >= 2 x Vs.

**Q19. How does DGA find faults?**
Faults crack oil/paper into gases. H2 = discharge; C2H2 = arcing; C2H4 = hot spot; CO/CO2 = paper. Watch the trend and ratios.

**Q20. What does a rising tan delta show?**
Insulation ageing or moisture. Compare with baseline. Capacitance change > 5 % means shorted layers in a condenser bushing.

**Q21. Why single-point earthing of CT secondary?**
Two earths make a parallel path and an unwanted circulating current, causing mis-operation of bus bar and differential relays.

**Q22. What is trip circuit supervision?**
A relay (74) continuously checks the trip coil, wiring and DC supply with CB open and closed, raising an alarm if a break occurs.

**Q23. Why are 2 DC batteries and 2 trip coils provided?**
Redundancy. DC failure must not leave the system without protection.

**Q24. Define step and touch potential.**
Step: voltage between two feet 1 m apart. Touch: voltage between hand (touching earthed metal) and feet. Keep both below tolerable limits (IEEE 80).

**Q25. Power swing blocking (PSB) - why?**
During a power swing the impedance enters the zones slowly and could cause wrong trips. PSB blocks distance zones. Out-of-step tripping (OOST) separates the system at a chosen point.

**Q26. Typical sequence for a transformer trip on Buchholz?**
Do not recharge. Collect gas sample, test (DGA, IR, ratio, winding resistance), inspect. Re-energise only after clearance by the maintenance engineer.

**Q27. What is the earth resistance target?**
Substation grid <= 1 ohm (large <= 0.5 ohm). Design for safe step and touch voltage, not only resistance.
