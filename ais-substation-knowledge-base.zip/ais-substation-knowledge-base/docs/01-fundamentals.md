# 1. Fundamentals

## 1.1 Voltage classes
| Nominal (kV) | Highest system voltage Um (kV) | Lightning impulse withstand (kVp) | Typical short-circuit rating | Creepage (typical) |
|---|---|---|---|---|
| 400 | 420 | 1425 (switching impulse 1050 kVp) | 40 or 50 kA, 1 s | 25 mm/kV x 420 = 10,500 mm |
| 220 | 245 | 1050 (power-freq 460 kV rms) | 40 or 31.5 kA, 1 s | 25 x 245 = 6,125 mm |
| 132 | 145 | 650 (power-freq 275 kV rms) | 31.5 or 25 kA, 1 s | 25 x 145 = 3,625 mm |

Creepage: 25 mm/kV = "heavy" pollution, 31 mm/kV = "very heavy" (IEC 60815). Use about 20 mm/kV for light/medium areas.

## 1.2 AIS vs GIS
| | AIS (air insulated) | GIS (SF6 insulated) |
|---|---|---|
| Space | Large | Very small (10-25 %) |
| Cost | Lower | Higher |
| Maintenance | Easy access, more frequent | Low, but specialist |
| Pollution/weather | Affected | Not affected |
| Extension | Easy | Needs planning |

## 1.3 Bus schemes (what is used where)
| Scheme | Features | Typical use |
|---|---|---|
| Single bus | Cheapest, bus fault = total outage | Small 132 kV |
| Main and transfer | Any CB can be bypassed via transfer bus | 132 / 220 kV |
| Double main (duplicate) bus | Flexible, bus coupler | 132 / 220 kV |
| Double main and transfer | Flexible + CB maintenance without outage | 220 kV |
| **One-and-half breaker (1.5 CB)** | 3 CBs for 2 circuits, very reliable, no outage for bus or CB maintenance | **400 kV** (and large 220 kV) |
| Ring / mesh | Each CB serves two circuits | Small to medium |

**Exam tip:** In a 1.5 CB diameter, the middle CB is the *tie* CB; the two outer CBs are the *main* CBs.

## 1.4 Typical air clearances (verify with CEA / utility standard)
| Clearance (mm) | 400 kV | 220 kV | 132 kV |
|---|---|---|---|
| Phase to earth | 3500 | 2100 | 1300 |
| Phase to phase | 4200 | 2100 | 1300 |
| Sectional (safety, working zone) | 6500 | 4300 | 4000 |
| Min. ground clearance (live part) | 8000 | 5500 | 4600 |

## 1.5 Bay types
Line bay - Transformer/ICT bay - Bus coupler - Bus transfer - Tie bay (1.5 CB) - Line reactor / Bus reactor bay - Capacitor bay (132 kV / 33 kV).

## 1.6 Typical line bay order (line to bus)
```
Line -> Wave trap -> CVT -> Line isolator (with earth switch) -> CT -> CB -> CT -> Bus isolator -> Bus
                        \-> LA (near line entry and transformers)
```
