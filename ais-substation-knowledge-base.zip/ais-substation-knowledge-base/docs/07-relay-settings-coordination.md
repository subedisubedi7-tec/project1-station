# 7. Relay Settings and Coordination

> Method + worked examples. Numbers are for learning. Use the approved study for real settings.
> Verify examples with `python3 tools/relay_calc.py`.

## 7.1 Data needed before any setting
Single line diagram, line/transformer impedance (Z1, Z0, MVA, %Z), CT/VT ratios and classes, max/min fault levels (3-phase, L-G), maximum load current, CB opening time, carrier scheme details, adjacent line data, existing settings of upstream/downstream relays, grid code requirements.

## 7.2 Basic relations
| Item | Formula |
|---|---|
| Fault MVA | MVA = sqrt(3) x kV x kA |
| Rated current | I = MVA x 1000 / (sqrt(3) x kV) A |
| Fault through transformer | 1/MVAsc = 1/MVAsource + (%Z/100)/MVArated |
| Primary to secondary ohm | Zsec = Zpri x CTR / VTR |
| IDMT time | t = TMS x k / ((I/Is)^a - 1)   (NI: 0.14, 0.02; VI: 13.5, 1; EI: 80, 2; LTI: 120, 1) |
| PSM | Fault current / (plug setting x CT primary) |

## 7.3 Over-current and earth-fault (51 / 51N) settings
1. **Pickup (phase):** 110-150 % of max load current (typical 125 %). It must be above the transformer/feeder emergency load and below the minimum fault current (with margin of at least 1.5).
2. **Pickup (earth fault):** 10-20 % of CT primary (typical), above the max unbalance, below the min earth-fault current.
3. **Curve:** NI for general feeders, VI/EI where fuses or grading with reclosers are needed.
4. **TMS:** start from the most downstream relay (lowest TMS), then work towards the source.
5. **Grading margin:** 0.3-0.4 s (numerical relays). Check at the max fault current at the downstream relay's location.
6. **High-set (50):** above the max through-fault current of the next bus (about 1.2 x) or above transformer inrush (8-12 x In) for transformer feeders.
7. Always check the **time curves overlay** (TCC plot) for the whole chain, including transformer damage curve and inrush point.

### Worked example A - IDMT grading
Relay B (downstream): CT 400/1, plug setting 100 % (Is = 400 A), TMS 0.1, NI curve. Fault at B's feeder = 4000 A.
- PSM = 4000 / 400 = 10. t_B = 0.1 x 0.14 / (10^0.02 - 1) = **0.297 s**.
- Relay A (upstream): CT 800/1, Is = 800 A. Needed time = 0.297 + 0.4 = 0.697 s.
- PSM_A = 4000 / 800 = 5. TMS_A = 0.697 x (5^0.02 - 1) / 0.14 = **0.163**. Choose next step **0.175**.
- Check: t_A = 0.175 x 0.14 / (5^0.02 - 1) = 0.749 s. Margin = 0.749 - 0.297 = **0.45 s** (OK).

## 7.4 Distance relay (21) setting method
**Reach rules (common practice, confirm with utility guideline):**
| Zone | Reach | Time |
|---|---|---|
| Z1 | 80 % of protected line (positive-sequence impedance) | Instantaneous |
| Z2 | 100 % line + 50 % of the shortest adjacent line, and not less than 120 % of the line | about 300-400 ms |
| Z3 | about 120 % x (protected line + longest adjacent line) (forward) | about 800-1000 ms |
| Z4 | Reverse, about 10-20 % of the protected line (needed for POTT / blocking) | Per scheme |

Checks:
- Z2 must not exceed the **Z1 of the adjacent line** for long lines (otherwise time-coordinate with its Z2).
- Z3 must not pick up at **maximum load** (load encroachment): use a load-blinder or set resistive reach so that R_reach < Zload_min x 0.7 (approx.).
- For **short lines**, Z1 reach is small and arc resistance becomes large relative to Z. Use a quadrilateral and high resistive reach.
- Ground reach R: allow for arc + tower footing resistance, but keep inside load limits.
- Residual compensation: kN = (Z0 - Z1) / (3 x Z1) (magnitude and angle both).
- For **parallel lines**, include zero-sequence mutual compensation (kM = Z0m / (3 x Z1)).
- Carrier aided scheme: Z2 time delays still set (as backup if carrier fails).
- Power swing (PSB): detect by rate of impedance change, block Z1/Z2/Z3, allow tripping for faults during the swing.

### Worked example B - 220 kV line, 40 km
- Line positive-sequence impedance 0.4 ohm/km -> **16 ohm** primary. Shortest adjacent line 20 km (8 ohm). Longest adjacent line 60 km (24 ohm).
- CT 800/1, CVT 220 kV / 110 V (ratio 2000). Factor CTR/VTR = 800/2000 = **0.4**.
- Z1 = 0.8 x 16 = 12.8 ohm -> **5.12 ohm** sec.
- Z2 = 16 + 0.5 x 8 = 20 ohm (>= 1.2 x 16 = 19.2) -> **8.00 ohm** sec, t = 350 ms.
- Z3 = 1.2 x (16 + 24) = 48 ohm -> **19.2 ohm** sec, t = 1000 ms.
- kN with Z0/Z1 = 3 (same angle): (3 - 1) / 3 = **0.667**.

## 7.5 Transformer differential (87T)
| Setting | Typical value |
|---|---|
| Pickup Id> | 0.2 x In (20 %) |
| Slope 1 | 25 % |
| Slope 2 | 50-80 % (after a break point about 1.5-2 x In) |
| High-set Id>> (unrestrained) | 6-10 x In (above inrush) |
| 2nd harmonic restraint | 15-20 % |
| 5th harmonic restraint | 25-35 % |
| REF (64R) pickup | 10-20 % of rated current of the winding |

Matching factors (numerical relays compute them, but check): 

### Worked example C - 100 MVA, 220/132 kV
- I_HV = 100,000 / (sqrt(3) x 220) = **262.4 A**; I_LV = 100,000 / (sqrt(3) x 132) = **437.4 A**.
- CT HV 400/1 -> 0.656 A. CT LV 600/1 -> 0.729 A.
- Mismatch factor = 0.729 / 0.656 = **1.111**. The relay's amplitude matching (for example, k_HV and k_LV) must correct this. Make sure the mismatch plus tap range (+/-10 %) is covered by slope 1.
- Phase shift: for YNd11 star CT on delta winding and delta CT on star winding (or software correction). Remove zero-sequence on star side if there is an earth source (use REF for it).

## 7.6 Bus bar differential setting (high impedance)
- Vs = I_f(sec) x (RCT + 2 x RL) at the max external fault.
- Relay setting voltage >= Vs; CT knee point **Vk >= 2 x Vs**. Check sensitivity: minimum primary current for operation = CTR x (Is + n x Im at Vs) with a margin.
- Use a metrosil (non-linear resistor) to limit the voltage across the relay during an internal fault.

### Worked example D
- If = 40 kA, CT 2000/1, RCT = 5 ohm, RL (one-way) = 2 ohm.
- I_sec = 40,000 / 2000 = 20 A. Vs = 20 x (5 + 4) = **180 V**. Vk >= **360 V**.

## 7.7 Breaker failure (LBB) timer example
- CB opening time 40 ms, relay reset 20 ms, safety margin 50 ms -> 110 ms. Choose **150 ms** (many 400 kV schemes 150-200 ms).
- Check it is shorter than Z2/backup time and the system stability limit (critical clearing time).

## 7.8 Coordination principles
1. **Selectivity:** the relay nearest the fault trips first.
2. **Time grading:** 0.3-0.4 s step between relays (more for older relays).
3. **Current grading:** pickup higher upstream.
4. **Zone grading:** distance zones overlap with time steps.
5. **Main-1 and Main-2 consistency:** same reach and logic in both, so either can protect alone.
6. **Remote end check:** the settings at the two ends of a line must match the scheme (carrier, AR).
7. **After any change** in network, transformer or line, re-run the short-circuit study and verify settings.
8. **Document:** setting sheet, calculation, approval, test report, date, engineer name.

## 7.9 Common mistakes
- Using positive-sequence data for earth-fault reach without kN.
- Not checking Z3 against load.
- Mixing primary and secondary ohm.
- Leaving old relay settings after changing the CT ratio.
- Forgetting mutual coupling in parallel lines.
- Setting 5th harmonic block too low, which prevents tripping during real over-fluxing faults.
- Using only max fault current and never the minimum fault current to check sensitivity.
