# Contributing
- Keep language simple. Use tables and short steps.
- Mark any utility-specific value as *typical* and name the standard or source.
- One topic per file. Open an issue before large changes.
- Python: plain Python 3, no extra packages, add a test for each new function.
